﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/* Napisz program, który mnoży elementy tablicy jednowymiarowej przez zadaną liczbę.
Mnożenie ma być wykonane w metodzie statycznej przyjmującej jako argumenty tablicę typu
int oraz liczbę całkowitą (mnożnik).

Wykonaj zadanie w dwóch wariantach:
a) Wewnątrz metody tworzona jest nowa tablica wynikowa, która ma być zwrócona
przez metodę.

b) Wyniki mnożenia elementów tablicy mają zostać umieszczone w tablicy będącej
argumentem metody (w tym wariancie metoda ma niczego nie zwracać).

Przykładowo dla tablicy o elementach {1,4,6,8,2} oraz mnożniku 2 program powinien
wyświetlić tablicę {2,8,12,16,4}. */

namespace Cwiczenie5._4
{
    class Program
    {
        #region Wariant I
        
        static int[] table1 = { 5, 6, 7, 8, 9 };
        static int multiplier = 3;

        static void Multiplying(int[] param1, int param2)
        {
            int[] table2 = new int[5];
            int j = 0;

            Console.Write("{");
            for (int i = 0; i < table1.Length; i++)
            {
                if (i < 4)
                {
                    table2[j] = table1[i] * multiplier;
                    Console.Write(table2[j] + ",");
                }
                else
                {
                    table2[j] = table1[i] * multiplier;
                    Console.Write(table2[j]);
                }
            }
            Console.Write("}");
            Console.ReadKey();
        }

        static void Main(string[] args)
        {
            Multiplying(table1, multiplier);
        }
        
        #endregion

        #region Wariant II
        /*
                static int[] table = { 5, 6, 7, 8, 9 };
                static int multiplier = 3;

                static void Multiplying(int[] arg1, int arg2)
                {
                    for (int i = 0; i < table.Length; i++)
                    {
                        table[i] = table[i] * multiplier;
                    }
                }

                static void Main(string[] args)
                {
                    Multiplying(table, multiplier);

                    Console.Write("{");
                    foreach (var num in table)
                    {
                        Console.Write(num + ",");
                    }
                    Console.SetCursorPosition(Console.CursorLeft - 1, Console.CursorTop);
                    Console.Write("}");
                    Console.ReadKey();
                }
                */
        #endregion
    }
}
